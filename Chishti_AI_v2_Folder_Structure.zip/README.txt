Paste the 'ai' folder into your project root:

Project/
 ├─ index.html
 ├─ reader/
 ├─ css/
 ├─ js/
 └─ ai/
