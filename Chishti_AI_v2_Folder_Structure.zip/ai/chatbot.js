// Main chatbot controller
