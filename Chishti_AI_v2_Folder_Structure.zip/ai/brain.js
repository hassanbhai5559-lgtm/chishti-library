// AI brain loader
